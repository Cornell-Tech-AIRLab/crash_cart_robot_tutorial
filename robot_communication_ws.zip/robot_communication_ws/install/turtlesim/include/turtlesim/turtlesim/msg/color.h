// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtlesim:msg/Color.idl
// generated code does not contain a copyright notice

#ifndef TURTLESIM__MSG__COLOR_H_
#define TURTLESIM__MSG__COLOR_H_

#include "turtlesim/msg/detail/color__struct.h"
#include "turtlesim/msg/detail/color__functions.h"
#include "turtlesim/msg/detail/color__type_support.h"

#endif  // TURTLESIM__MSG__COLOR_H_
