// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtlesim:action/RotateAbsolute.idl
// generated code does not contain a copyright notice

#ifndef TURTLESIM__ACTION__ROTATE_ABSOLUTE_H_
#define TURTLESIM__ACTION__ROTATE_ABSOLUTE_H_

#include "turtlesim/action/detail/rotate_absolute__struct.h"
#include "turtlesim/action/detail/rotate_absolute__functions.h"
#include "turtlesim/action/detail/rotate_absolute__type_support.h"

#endif  // TURTLESIM__ACTION__ROTATE_ABSOLUTE_H_
