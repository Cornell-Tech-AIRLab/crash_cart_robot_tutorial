#!/bin/bash

sudo bash -c "cd /home/tauhid/ros2_ws && . install/setup.bash && ros2 run light_pkg light_node"
