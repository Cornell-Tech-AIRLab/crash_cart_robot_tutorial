from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()

    light_publisher_node = Node(
        package = "light_pkg",
        executable = "light_node"
    )

    alert_publisher_node = Node(
        package = "alert_pkg",
        executable = "alert_node"
    )
    dialogue_publisher_node = Node(
        package = "dialogue_pkg",
        executable = "dialogue_node"
    )
    ld.add_action(alert_publisher_node)
    #ld.add_action(dialogue_publisher_node)
    ld.add_action(light_publisher_node )

    return ld