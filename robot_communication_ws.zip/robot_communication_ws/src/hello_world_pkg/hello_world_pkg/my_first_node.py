import time
import board
import neopixel
from tkinter import Tk, Button

# Initialize NeoPixel strip
pixels = neopixel.NeoPixel(board.D18, 4, brightness=1.0, auto_write=False)

def fill_color():
    # Function to light up LEDs with a specific pattern for a few seconds
    pixels.fill((0, 0, 0))  # Turn all LEDs off
    pixels.show()
    time.sleep(0.5)  # Brief pause
    # Set individual LEDs
    pixels[0] = (255, 0, 0)  # Red
    pixels[1] = (0, 255, 0)  # Green
    pixels[2] = (0, 0, 255)  # Blue
    pixels[3] = (255, 255, 0)  # Yellow
    pixels.show()  # Update LEDs all at once
    time.sleep(3)  # Display color for 3 seconds
    pixels.fill((0, 0, 0))  # Turn all LEDs off again
    pixels.show()

def slider_effect():
    # Simple light slider effect
    for i in range(4):  # Loop through each LED
        pixels.fill((0, 0, 0))  # Turn all LEDs off
        pixels[i] = (255, 100, 0)  # Set current LED to orange
        pixels.show()
        time.sleep(0.1)
    for i in range(3, -1, -1):  # Loop back in reverse
        pixels.fill((0, 0, 0))
        pixels[i] = (0, 255, 100)  # Set current LED to light green
        pixels.show()
        time.sleep(0.1)

# Set up Tkinter GUI
root = Tk()
root.title("LED Controller")

# Buttons for control
color_button = Button(root, text="Color Fill", command=fill_color)
color_button.pack(pady=20)

slider_button = Button(root, text="Slider Effect", command=slider_effect)
slider_button.pack(pady=20)

root.mainloop()
