import rclpy
from rclpy.node import Node
import tkinter as tk
from threading import Thread
from geometry_msgs.msg import Twist  # Import Twist message type for sending velocity commands

class MovementNode(Node):
    def __init__(self):
        super().__init__('movement_node')
        self.publisher = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)  # Publisher to send commands to turtlesim

        # Start the GUI in a separate thread
        self.gui_thread = Thread(target=self.start_gui, daemon=True)
        self.gui_thread.start()

    def start_gui(self):
        self.root = tk.Tk()
        self.root.title("ROS2 Movement Interface")

        # Create label and entry for text input
        tk.Label(self.root, text="Enter or click a movement number (1-5):").pack(padx=20, pady=10)
        self.entry = tk.Entry(self.root)
        self.entry.pack(padx=20, pady=10)
        self.entry.bind("<Return>", self.on_enter)

        # Create buttons for direct selection
        button_frame = tk.Frame(self.root)
        button_frame.pack(padx=20, pady=10)
        for number in range(1, 6):
            button = tk.Button(button_frame, text=str(number), 
                               command=lambda num=str(number): self.button_click(num))
            button.pack(side=tk.LEFT, padx=5)

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.mainloop()

    def on_enter(self, event):
        self.process_input()

    def button_click(self, number):
        self.process_input(number)

    def process_input(self, number=None):
        if number is None:
            number = self.entry.get()
        movement_command = self.create_movement_command(number)
        if movement_command:
            self.publisher.publish(movement_command)
        else:
            self.get_logger().info("Invalid movement number")

    def create_movement_command(self, number):
        cmd = Twist()
        if number == '1':
            cmd.linear.x = 2.0  # Move forward
        elif number == '2':
            cmd.angular.z = 1.0  # Turn left
        elif number == '3':
            cmd.angular.z = -1.0  # Turn right
        elif number == '4':
            cmd.linear.x = -2.0  # Move backward
        elif number == '5':
            cmd.linear.x = 0.0; cmd.angular.z = 0.0  # Stop
        else:
            return None
        return cmd

    def on_close(self):
        self.destroy_node()
        self.root.quit()
        rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    movement_node = MovementNode()
    rclpy.spin(movement_node)
    movement_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
